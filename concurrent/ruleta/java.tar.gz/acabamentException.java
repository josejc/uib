
public class acabamentException extends Exception
{
	public acabamentException()
	{
		// initialise instance variables
	}
}
