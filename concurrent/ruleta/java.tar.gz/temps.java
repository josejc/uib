import java.lang.*;
import java.util.*;

/**
 * Classe que controlara l'espai temporal mentre la banca acepta apostes.
 */
public final class temps extends Thread {

   // Per generar nombres aleatoris
   private final Random rand = new Random();
	
   /**
   * M�tode per acabar. Cap altre proc�s l'invocar�.
   */
   public void finalitzar() throws acabamentException {
      System.out.println("\t\tTemps ha d'acabar.");
      throw new acabamentException();
   }
	
   /**
   * Constructor. No hi ha cap relaci� guardi�-depenent.
   */
   public temps() {
      System.out.println("\t\tTemps creat.");
      setDaemon(true);
   }
	
   /**
   * M�tode d'execuci�
   */
   public void run () {
	    
      System.out.println("\t\tInici d'execucio del temps (control espai temporal).");
	    	    
      try {
         while (true) {
            /**
	    * Aquest bucle es repeteix fins que s'acaba el programa.
	    */
	    if (regioCritica.acabar()) finalitzar();

	    // Esperam per q la banca posi en marxa el temps... ;)
	    def.iniTemps.w();
	    // La banca acepta apostas durant un espai temporal entre 5..10 segons i la darrera aposta
	    try {
	       sleep(def.SEGON*(5+rand.nextInt(5)));
	    } catch (InterruptedException e) {}
	    // Avisam a la banca q ha finalitzat el temps...
	    def.avisBanca.s();
         }
      } catch (acabamentException e) {}
   }
      
}
