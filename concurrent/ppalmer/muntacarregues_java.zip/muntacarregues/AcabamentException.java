
public class AcabamentException extends Exception
{
	public AcabamentException()
	{
		// initialise instance variables
	}
}
